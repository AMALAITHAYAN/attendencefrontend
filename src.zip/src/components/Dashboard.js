import React from 'react';
import { useNavigate } from 'react-router-dom';
// import './Dashboard.css'; // No longer needed
import logo from './assets/logo.png'; // Make sure this path is correct

const Dashboard = () => {
  const navigate = useNavigate();

  const styles = `
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    .dashboard-blue-bg {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      font-family: 'Poppins', sans-serif;
      /* --- The Core Blue Gradient Background --- */
      background: linear-gradient(135deg, #020617, #0f172a, #1e3a8a);
      color: #e2e8f0;
      padding: 2rem 1.5rem;
      box-sizing: border-box;
    }

    .dashboard-blue-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      text-align: center;
      margin-bottom: 2.5rem;
    }

    .dashboard-blue-logo {
      width: 50px;
      height: 50px;
    }

    .dashboard-blue-header h1 {
      font-size: 2.5rem;
      font-weight: 600;
      color: #f8fafc;
      text-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
      margin: 0;
    }

    .dashboard-blue-container {
      max-width: 500px;
      width: 100%;
      /* --- Semi-transparent blue background to complement the gradient --- */
      background-color: rgba(15, 23, 42, 0.6); /* slate-900 with transparency */
      backdrop-filter: blur(12px);
      /* --- A strong, solid, blue-themed border --- */
      border: 2px solid rgba(59, 130, 246, 0.4); 
      border-radius: 16px;
      padding: 2.5rem;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
      text-align: center;
    }

    .dashboard-blue-subtitle {
      font-size: 1.1rem;
      color: #93c5fd; /* Light accent blue */
      margin-bottom: 2rem;
      font-weight: 400;
    }
    
    .dashboard-blue-buttons-grid {
      display: flex;
      flex-direction: column;
      gap: 1.2rem;
    }
    
    .dashboard-blue-btn {
      padding: 1rem;
      font-size: 1.1rem;
      font-weight: 600;
      color: #e2e8f0;
      background-color: #1e293b; /* A solid dark slate-blue */
      border: 2px solid #334155; /* Muted border */
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.2s ease-out;
      outline: none;
      box-shadow: 0 4px 10px rgba(0,0,0,0.3);
      text-align: center;
    }

    .dashboard-blue-btn:hover {
      transform: translateY(-3px);
      border-color: #3b82f6; /* Bright blue border on hover */
      color: #ffffff;
      /* --- The gradient appears on hover for a dynamic effect --- */
      background: linear-gradient(to right, #3b82f6, #2563eb);
      box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
    }
    
    .dashboard-blue-btn:active {
      transform: translateY(-1px);
      box-shadow: 0 2px 10px rgba(59, 130, 246, 0.2);
    }
    
    .dashboard-blue-btn-logout {
      background-color: rgba(127, 29, 29, 0.2);
      border-color: rgba(239, 68, 68, 0.4);
      color: #fca5a5;
    }

    .dashboard-blue-btn-logout:hover {
      background: linear-gradient(to right, #ef4444, #dc2626);
      border-color: #ef4444;
      color: #ffffff;
      box-shadow: 0 6px 20px rgba(239, 68, 68, 0.3);
    }

    /* --- Responsive Design --- */
    @media (max-width: 768px) {
      .dashboard-blue-bg {
        padding: 1.5rem 1rem;
        justify-content: flex-start;
      }

      .dashboard-blue-header {
        margin-bottom: 2rem;
      }

      .dashboard-blue-header h1 {
        font-size: 2rem;
      }

      .dashboard-blue-logo {
        width: 40px;
        height: 40px;
      }
      
      .dashboard-blue-container {
        padding: 1.5rem;
        border-width: 1px;
      }
    }
  `;

  return (
    <>
      <style>{styles}</style>
      <div className="dashboard-blue-bg">
        <div className="dashboard-blue-header">
          <img src={logo} alt="Company Logo" className="dashboard-blue-logo" />
          <h1>Admin Dashboard</h1>
        </div>

        <div className="dashboard-blue-container">
          <p className="dashboard-blue-subtitle">Choose an option to manage</p>
          <div className="dashboard-blue-buttons-grid">
            <button className="dashboard-blue-btn" onClick={() => navigate('/manage-employees')}>
              Manage Students
            </button>
            <button className="dashboard-blue-btn" onClick={() => navigate('/attendance')}>
              Attendance
            </button>
            <button className="dashboard-blue-btn" onClick={() => navigate('/reports')}>
              Reports
            </button>
            <button className="dashboard-blue-btn" onClick={() => navigate('/shift-schedule')}>
              Assign Periods
            </button>
            <button className="dashboard-blue-btn dashboard-blue-btn-logout" onClick={() => navigate('/')}>
              Logout
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;