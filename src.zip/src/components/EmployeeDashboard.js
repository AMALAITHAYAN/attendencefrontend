import React, { useState, useRef } from 'react';
/* removed external CSS per request */
// import './Dashboard.css';
import logo from './assets/logo.png';
import axios from 'axios';
import { getDistance } from 'geolib';
import {
  MapPin,
  MapPinCheck,
  LocateFixed,
  Video,
  Camera,
  CheckCircle2,
  LogOut,
  UserRound,
  Clock4,
  IdCard,
  AlertCircle,
  CheckSquare,
  XCircle,
  Loader2
} from 'lucide-react';

const companyLocation = {
  latitude: 10.954240408591504,
  longitude: 76.95956362661686
};

const EmployeeDashboard = () => {
  const user = JSON.parse(localStorage.getItem('user'));
  const [attendanceId, setAttendanceId] = useState(null);
  const [message, setMessage] = useState('');
  const [step, setStep] = useState('idle');
  const [snapshot, setSnapshot] = useState(null);
  const videoRef = useRef(null);

  const verifyLocation = () => {
    setMessage('Verifying location...');
    setStep('location');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const distance = getDistance(
          { latitude, longitude },
          companyLocation
        );

        if (distance <= 1000) {
          setMessage('✅ Location verified.');
          setStep('camera');
          startCamera();
        } else {
          setMessage('❌ You are not at the office location.');
          setStep('idle');
        }
      },
      () => { setMessage('❌ Location access denied.'); setStep('idle'); }
    );
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      setMessage('❌ Camera access denied.');
    }
  };

  const captureFace = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 240;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg');

    fetch(dataUrl)
      .then(res => res.blob())
      .then(blob => {
        setSnapshot(URL.createObjectURL(blob));
        verifyFace(blob);
      });
  };

  const verifyFace = async (blob) => {
    try {
      const formData = new FormData();
      formData.append('image', blob, 'face.jpg');  // KEY FIXED: "image"

      setStep('verifyingFace');
      const res = await axios.post('http://localhost:8080/api/face/checkin', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        }
      });

      if (res.data.includes("Not Matched")) {
        setMessage("❌ Face not matched. Access denied.");
        setStep("idle");
        stopCamera();
        return;
      }

      setMessage(`✅ Face match result: ${res.data}`);
      setStep('confirmed'); // Allow Confirm Check-In button
    } catch (err) {
      setMessage('❌ Face verification failed.');
      console.error(err);
      setStep('idle');
      stopCamera();
    }
  };

  const checkIn = async () => {
    try {
      const res = await axios.post(`http://localhost:8080/api/attendance/checkin/${user.id}`, {
        snapshot
      });
      setAttendanceId(res.data.id);
      setMessage('✅ Checked in successfully.');
      stopCamera();
    } catch (err) {
      setMessage(err.response?.data || '❌ Already checked in today.');
    }
  };

  const checkOut = async () => {
    if (!attendanceId) {
      setMessage('⚠️ You need to check in first.');
      return;
    }

    try {
      await axios.post(`http://localhost:8080/api/attendance/checkout/${attendanceId}`);
      setMessage('✅ Checked out successfully.');
    } catch (err) {
      setMessage('❌ Failed to check out.');
    }
  };

  const stopCamera = () => {
    const stream = videoRef.current?.srcObject;
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
    }
  };

  const logout = () => {
    stopCamera();
    localStorage.removeItem('user');
    window.location.href = '/';
  };

  return (
    <div className="dashboard-bg">
      <style>{`
        :root{
          --bg:#070b16; --bg2:#0b1224; --card:#0c142a; --card2:#0a1226;
          --text:#e8eef6; --muted:#a4b1c8;
          --border:#1b2a4a; --ring:rgba(99,102,241,.25);
          --primary:#8b5cf6; --accent:#06b6d4; --danger:#ef4444; --success:#10b981; --warn:#f59e0b;
        }
        *{box-sizing:border-box}
        html,body,#root{height:100%}
        .dashboard-bg{
          min-height:100dvh; padding:16px; display:flex; flex-direction:column; gap:16px;
          background:
            radial-gradient(900px 420px at 20% -10%, rgba(27,39,80,.7), transparent 60%),
            radial-gradient(900px 520px at 100% 0%, rgba(6,182,212,.18), transparent 55%),
            linear-gradient(160deg, #060c1a 0%, var(--bg2) 40%, #071022 100%);
          color:var(--text);
          font-family: Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial;
        }
        .dashboard-header{
          display:flex; align-items:center; gap:12px; padding:12px;
          border:1px solid var(--border); border-radius:16px;
          background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
          backdrop-filter: blur(8px);
        }
        .dashboard-logo{
          width:42px; height:42px; border-radius:10px; object-fit:contain;
          background:#0e1730; padding:6px; border:1px solid var(--border);
        }
        .dashboard-header h1{
          font-size:18px; margin:0; font-weight:800; letter-spacing:.2px;
          display:flex; align-items:center; gap:8px;
        }
        .dashboard-container{
          display:grid; gap:16px;
          border:1px solid var(--border); border-radius:18px;
          padding:18px;
          background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));
          backdrop-filter: blur(8px);
        }
        .dashboard-subtitle{
          margin:0; color:var(--muted); font-size:14px; text-align:left;
        }

        .cards{
          display:grid; grid-template-columns: repeat(3, 1fr); gap:12px;
        }
        .card{
          border:1px solid var(--border); border-radius:16px; padding:14px; display:grid; gap:8px;
          background: linear-gradient(180deg, rgba(255,255,255,.02), rgba(255,255,255,.01));
        }
        .card h3{ margin:0; font-size:14px; color:var(--muted); font-weight:700; letter-spacing:.2px; }
        .stat{
          display:flex; align-items:center; gap:10px; font-size:14px;
        }
        .chip{
          display:inline-flex; gap:6px; align-items:center;
          padding:6px 10px; border-radius:999px; font-size:12px; font-weight:700; letter-spacing:.2px;
          border:1px solid var(--border); color:#d1e4ff; background: rgba(11, 48, 120, .25);
        }
        .buttons{
          display:flex; flex-wrap:wrap; gap:10px; align-items:center;
        }
        .btn{
          display:inline-flex; align-items:center; gap:8px;
          padding:10px 12px; border:none; border-radius:12px; cursor:pointer; color:#fff; font-weight:800; letter-spacing:.2px;
          background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
          box-shadow: 0 12px 32px rgba(6,182,212,.22);
          transition: transform .05s ease, box-shadow .2s ease, opacity .2s;
        }
        .btn:hover{ box-shadow: 0 18px 44px rgba(6,182,212,.28); }
        .btn:active{ transform: translateY(1px); }
        .btn[disabled]{ opacity:.65; cursor:not-allowed; }

        .btn.secondary{
          background: linear-gradient(90deg, #2e3350 0%, #25304a 100%);
        }
        .btn.danger{ background: linear-gradient(90deg, #c2410c 0%, #ef4444 100%); }
        .btn.success{ background: linear-gradient(90deg, #0ea5e9 0%, #10b981 100%); }
        .btn.warn{ background: linear-gradient(90deg, #f59e0b 0%, #ef4444 100%); }

        .media{
          display:grid; gap:8px; justify-items:center;
          border:1px dashed var(--border); border-radius:14px; padding:12px; background: rgba(12,20,42,.35);
        }
        .media video{ width:100%; max-width:420px; height:auto; border-radius:12px; border:1px solid var(--border); background:#000; }
        .media img{ width:200px; height:auto; border-radius:12px; border:1px solid var(--border); }

        .message{
          margin-top:6px; font-weight:700; color:#e6f0ff;
          display:flex; align-items:center; gap:8px;
        }
        .message.error{ color:#fecaca; }
        .message.success{ color:#d1fae5; }
        .message.warn{ color:#fde68a; }

        /* Responsive */
        @media (max-width: 900px){
          .cards{ grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 600px){
          .dashboard-header{ padding:10px; }
          .dashboard-header h1{ font-size:16px; }
          .dashboard-container{ padding:14px; }
          .cards{ grid-template-columns: 1fr; }
          .buttons{ gap:8px; }
          .btn{ width:100%; justify-content:center; }
        }
      `}</style>

      {/* Header */}
      <div className="dashboard-header">
        <img src={logo} alt="Company Logo" className="dashboard-logo" />
        <h1>
          <UserRound size={18} />
          Welcome, {user?.name || 'Employee'}
        </h1>
      </div>

      {/* Content */}
      <div className="dashboard-container">
        <p className="dashboard-subtitle">This is your Attendance Dashboard</p>

        {/* Top stats / status */}
        <div className="cards">
          <div className="card">
            <h3>Status</h3>
            <div className="stat">
              <MapPin size={16} />
              <span>Office Radius: <span className="chip"><LocateFixed size={14}/> 1 km</span></span>
            </div>
          </div>
          <div className="card">
            <h3>Attendance</h3>
            <div className="stat">
              <Clock4 size={16} />
              <span>Session: {attendanceId ? <span className="chip"><CheckSquare size={14}/> Active</span> : <span className="chip"><XCircle size={14}/> None</span>}</span>
            </div>
          </div>
          <div className="card">
            <h3>Profile</h3>
            <div className="stat">
              <IdCard size={16} /><span>ID: {user?.id ?? '—'}</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="buttons">
          {step === 'idle' && (
            <button className="btn" onClick={verifyLocation}>
              <MapPinCheck size={16} /> Start Check-In
            </button>
          )}

          {step === 'location' && (
            <button className="btn secondary" disabled>
              <Loader2 size={16} className="spin" style={{animation: 'spin 1s linear infinite'}} /> Verifying Location…
            </button>
          )}

          {step === 'camera' && (
            <>
              <div className="media">
                <Video size={16} />
                <video ref={videoRef} autoPlay width="320" height="240" />
                <button className="btn success" onClick={captureFace}>
                  <Camera size={16} /> Capture Face
                </button>
              </div>
            </>
          )}

          {step === 'verifyingFace' && (
            <button className="btn secondary" disabled>
              <Loader2 size={16} className="spin" style={{animation: 'spin 1s linear infinite'}} /> Verifying Face…
            </button>
          )}

          {step === 'confirmed' && (
            <>
              <div className="media">
                <img src={snapshot} alt="Captured Face" width="200" />
                <button className="btn" onClick={checkIn}>
                  <CheckCircle2 size={16} /> Confirm Check-In
                </button>
              </div>
            </>
          )}

          <button className="btn secondary" onClick={checkOut} disabled={!attendanceId}>
            <Clock4 size={16} /> Check Out
          </button>

          <button className="btn secondary" onClick={() => (window.location.href = '/employee-profile')}>
            <UserRound size={16} /> My Profile
          </button>

          <button className="btn danger" onClick={logout}>
            <LogOut size={16} /> Logout
          </button>
        </div>

        {message && (
          <p
            className={
              'message ' +
              (message.startsWith('✅') ? 'success ' : '') +
              (message.startsWith('❌') ? 'error ' : '') +
              (message.startsWith('⚠️') ? 'warn ' : '')
            }
          >
            {message.startsWith('✅') ? <CheckCircle2 size={16}/> :
             message.startsWith('❌') ? <AlertCircle size={16}/> :
             message.startsWith('⚠️') ? <AlertCircle size={16}/> : null}
            <span>{message}</span>
          </p>
        )}
      </div>
    </div>
  );
};

export default EmployeeDashboard;
